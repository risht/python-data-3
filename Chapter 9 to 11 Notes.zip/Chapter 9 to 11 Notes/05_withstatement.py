f = open("file.txt")
data = f.read()

f.close()   


# the same statement can be written like this:
with open("file.txt") as f:
    #data = f.read()
    print(data)

# You dont have to close the file explicitly when using with statement.

