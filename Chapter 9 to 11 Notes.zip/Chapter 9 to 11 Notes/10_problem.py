with open("old.txt","w") as f:
    f.write("")