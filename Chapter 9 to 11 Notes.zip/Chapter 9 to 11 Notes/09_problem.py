with open("this.txt") as f:
    content1 = f.read()

with open("thiscopy.txt") as f:
     content2 = f.read()

if(content1 == content2):
    print("The files are the same")
else:
    print("The files are different")
    