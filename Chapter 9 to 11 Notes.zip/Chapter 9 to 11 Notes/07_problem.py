

with open("log.txt", "r") as f:
    lines = f.readlines()

line = 1

for line_content in lines:
    if("python" in line_content):
        print(f"Python is mentioned in the log file. Line no : {line}")
        break
    line += 1

else:
    print("Python is not mentioned in the log file.")
  

