f = open("file.txt")

#lines = f.readlines() # it returns a list of lines in the file

#print(lines,type(lines)) # it will print the list of lines in the file


# l1 = f.readline() # it returns a single line in the file
# print(l1,type(l1))

# l2 = f.readline() 
# print(l2,type(l2))

# l3 = f.readline() 
# print(l3,type(l3))


# l4 = f.readline() 
# print(l4,type(l4))


# l5 = f.readline() 
# print(l5=="") # it will print True if the line is empty, otherwise False

# line = f.readline
# while(line!=""):
#     print(line) # it will print the line in the file
#     line = f.readline() # it will read the next line in the file

with open("file.txt", "r") as file:
    for line in file:
        print(line.strip())

f.close()    # To close the file

