words = ["Donkey","Bad","Stupid"]

with open("file1.txt") as f:
    cq = f.read()
    
for word in words:
    cq = cq.replace(word, "#" * len(word))

with open("file1.txt","w") as f:
    f.write(cq)