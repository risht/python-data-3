f = open("poems.txt")
data = f.read()

if "twinkle" in data:
    print("twinkle found")
else:
    print("twinkle not found")

f.close()   