word = "Donkey"

with open("file1.txt") as f:
    cq = f.read()
    
c1 = cq.replace(word, "######")

with open("file1.txt","w") as f:
    f.write(c1)