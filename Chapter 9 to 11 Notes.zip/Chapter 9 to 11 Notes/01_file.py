# TO READ THE FILE
f = open("file.txt")
data = f.read()
print(data)
f.close()    # To close the file







