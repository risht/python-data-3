st = "rish asda sda"

myfile = open("myfile.txt", "w")

myfile.write(st)

myfile.close()    # To close the file

